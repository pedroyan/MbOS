﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MbOS.FileDomain.DataStructures {
	public enum FileOperationCode {
		CreateFile,
		DeleteFile
	}
}
